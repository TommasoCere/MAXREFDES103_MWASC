package com.maximintegrated.bluetooth.livedata

enum class DiscoveryState {
    DISCOVERING,
    NOT_DISCOVERING
}