package com.maximintegrated.maximsensorsapp.sports_coaching

import com.maximintegrated.algorithms.sports.SportsCoachingSession

class SportsCoachingManager {
    companion object {
        var currentSession = SportsCoachingSession.UNDEFINED
    }
}