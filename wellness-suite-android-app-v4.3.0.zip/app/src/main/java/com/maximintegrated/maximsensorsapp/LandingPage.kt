package com.maximintegrated.maximsensorsapp

interface LandingPage {
}