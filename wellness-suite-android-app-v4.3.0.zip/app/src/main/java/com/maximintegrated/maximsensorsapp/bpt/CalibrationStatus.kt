package com.maximintegrated.maximsensorsapp.bpt

enum class CalibrationStatus{
    IDLE,
    STARTED,
    PROCESSING,
    SUCCESS,
    FAIL
}