package com.maximintegrated.maximsensorsapp

interface IOnBackPressed {
    fun onBackPressed(): Boolean
    fun onStopMonitoring()
}