package com.maximintegrated.maximsensorsapp.sleep.database

class SearchFile(
    var exist: Int,
    var fileName: String,
    var md5: String
)