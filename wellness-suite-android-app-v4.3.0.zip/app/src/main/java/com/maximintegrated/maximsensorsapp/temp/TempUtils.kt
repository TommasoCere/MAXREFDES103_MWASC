package com.maximintegrated.maximsensorsapp.temp

fun celsiusToFahrenheit(celsius: Float) = celsius * 1.8f + 32

fun fahrenheitToCelsius(fahrenheit: Float) = (fahrenheit - 32) / 1.8f