package com.maximintegrated.maximsensorsapp

enum class Scd(val displayName: String) {
    NO_DECISION("No Decision"),
    OFF_SKIN("Off Skin"),
    ON_OBJECT("On Object"),
    ON_SKIN("On Skin")
}